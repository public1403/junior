#!/bin/bash

# define
#CC=arm-linux-gcc
CC=gcc
INSTALLPATH=/root/mp3/install
TARGET=madplay.static

# show param
echo "CC="$CC
echo "INSTALLPATH="$INSTALLPATH
echo "TARGET="$TARGET

# build stage
echo "Begin build static..."

# build command
$CC -Wall -O2 -fomit-frame-pointer -o $TARGET madplay.o getopt.o getopt1.o version.o resample.o filter.o tag.o crc.o rgain.o player.o audio.o audio_aiff.o audio_cdda.o audio_hex.o audio_null.o audio_raw.o audio_snd.o audio_wave.o audio_oss.o -L$INSTALLPATH/lib $INSTALLPATH/lib/libmad.a $INSTALLPATH/lib/libid3tag.a -lz -lm -static

# end
echo $TARGET" build finish!"

